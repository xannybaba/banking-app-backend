import React, { useState } from 'react';
import axios from 'axios';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    const res = await axios.post('http://localhost:5000/api/auth/login', { email, password });
    alert("Logged in as " + res.data.user.email + " (" + res.data.user.role + ")");
    setRole(res.data.user.role);
    if (res.data.user.role === 'admin') {
      localStorage.setItem('adminToken', res.data.token);
    }
  };

  return (
    <div>
      <form onSubmit={handleLogin}>
        <h2>Login</h2>
        <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required />
        <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required />
        <button type="submit">Login</button>
      </form>
      {role === 'admin' && <a href="/admin">Go to Admin Dashboard</a>}
    </div>
  );
}