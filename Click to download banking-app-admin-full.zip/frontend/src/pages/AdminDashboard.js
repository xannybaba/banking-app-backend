import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function AdminDashboard() {
  const [users, setUsers] = useState([]);

  const fetchUsers = async () => {
    const token = localStorage.getItem('adminToken');
    const res = await axios.get('http://localhost:5000/api/admin/users', {
      headers: { Authorization: 'Bearer ' + token }
    });
    setUsers(res.data);
  };

  const deleteUser = async (id) => {
    const token = localStorage.getItem('adminToken');
    await axios.delete('http://localhost:5000/api/admin/users/' + id, {
      headers: { Authorization: 'Bearer ' + token }
    });
    fetchUsers();
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div>
      <h1>Admin Dashboard</h1>
      <h3>User Accounts</h3>
      <table border="1">
        <thead>
          <tr>
            <th>Email</th>
            <th>Balance</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user._id}>
              <td>{user.email}</td>
              <td>{user.balance}</td>
              <td>{user.role}</td>
              <td>
                <button onClick={() => deleteUser(user._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}